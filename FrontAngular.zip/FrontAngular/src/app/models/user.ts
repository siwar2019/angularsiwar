export class User{

    constructor(    
        public _id?: String,
        public firstname?: string,
        public lastname?: string,
        public tel?: string,
        public email?: string,
        public password?: string, ){

    }
}